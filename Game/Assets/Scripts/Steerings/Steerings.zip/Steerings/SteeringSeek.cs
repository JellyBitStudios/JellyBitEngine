﻿using System.Collections;
using System;
using JellyBitEngine;

public class SteeringSeek : SteeringAbstract
{
    public Vector3 GetSeek(Agent agent)
    {
        if (agent == null)
            return new Vector3(0.0f, 0.0f, 0.0f);

        Vector3 direction = (agent.destination - agent.transform.position).normalized();
        direction *= agent.agentConfiguration.maxAcceleration;
        return direction;
    }
}